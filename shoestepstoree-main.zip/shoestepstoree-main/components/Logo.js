import Image from "next/image"

const Logo = () => {
    <Image src="../images/sssslogo.PNG"
    height={596}
    width={886}
    alt="logo"
     />
  };
  export default Logo;