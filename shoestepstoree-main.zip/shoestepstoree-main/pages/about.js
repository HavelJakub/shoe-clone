import Layout from '../components/Layout';
import styles from "../styles/about.module.css";

export default function About()
{
    return(
        <Layout>
        <main className='main'>
        <div className="about">
        <Image width="248" height="167" alt="" src="/ssslogo.png"/>
            <div className="about-text">
                <h2 className='h2'>O mně</h2>
                <h5 className='h5'>Hráč snad i muzikant</h5>
                <p className='p'>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.    
                Duis risus. Nam sed tellus id magna elementum tincidunt.
                Nullam feugiat, turpis at pulvinar vulputate, erat libero
                tristique tellus, nec bibendum odio risus sit amet ante.
                Aliquam in lorem sit amet leo accumsan lacinia. Etiam ligula
                pede, sagittis quis, interdum ultricies, scelerisque eu. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam at arcu a est sollicitudin euismod. Integer lacinia. Morbi leo mi, nonummy eget tristique non, rhoncus non leo. Aenean vel massa quis mauris vehicula lacinia. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Curabitur bibendum justo non orci.</p>
            </div>
        </div>

        </main>
        </Layout>
    )
}